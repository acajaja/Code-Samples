<?php

namespace Interfaces;

/**
 * Description of MenuInterface
 *
 * @author clif jackson
 */
interface MenuInterface
{
	public function render();
}
